<?php
//000000000600
 exit();?>
a:4:{s:7:"vodtype";a:1:{s:6:"动作";s:9:"动作片";}s:7:"arttype";a:1:{s:6:"头条";s:6:"头条";}s:9:"actortype";a:1:{s:0:"";s:0:"";}s:11:"websitetype";a:1:{s:0:"";s:0:"";}}