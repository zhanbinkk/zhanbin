<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:42:"template/default_pc/html/public/close.html";i:1552223570;}*/ ?>
<!DOCTYPE html>
<html lang="en">
	<head>
	<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
	<title>网站维护中......</title>
	<link rel="stylesheet" href="/static/css/home.css">
	<style>
		body{background:#F9FAFD;color:#818181;}
	</style>
</head>
<body>
<div class="mac_msg_jump">
	<div class="msg_jump_tit">非常抱歉，网站正在维护中...</div>
	<div class="title">亲爱的站长们：</div>
	<div class="text">
		<?php echo $close_tip; ?>
	</div>
</div>
</body>
</html>



