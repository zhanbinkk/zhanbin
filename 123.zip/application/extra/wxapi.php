<?php
return array (
  'xiaoxiao' => 
  array (
    'id' => 'xiaoxiao',
    'app' => '微信',
    'info' => 'info',
    'admin' => 'guo',
    'des' => '',
    'name' => '',
    'WxKey' => '',
    'site' => 
    array (
      'appid' => '',
      'AppSecret' => '',
      'message' => 
      array (
        'radio' => '0',
        'tmpIds' => '',
      ),
      'sharepic' => 'https://shop.io.mi-img.com/app/shop/img?id=shop_067ab34c3d7cd342b7f054573848f941.jpeg',
      'kefu' => 
      array (
        'type' => '0',
        'url' => ' https://mp.weixin.qq.com/s/3xGOj-gKDtgE20ZIEdPMUg',
      ),
      'share' => 
      array (
        'type' => '0',
        'wxText' => '微信搜索小程序《剧场有约》',
      ),
      'file' => 
      array (
        'type' => '0',
        'qiniu' => 
        array (
          'ak' => '',
          'sk' => '',
          'name' => '',
          'host' => '',
        ),
      ),
      'platform' => '1',
      'ip' => 
      array (
        'radio' => '1',
        'text' => '腾讯云',
      ),
      'login' => 
      array (
        'radio' => '1',
        'num' => '8',
      ),
    ),
    'encrypt' => 
    array (
      'radio' => '1',
      'iv' => '',
      'key' => '',
    ),
    'weeks' => '1000,1001,1005,1006,1007,1008,1010,1011,1013,1014,1017,1022,1023,1024,1027,1035,1036,1037,1038,1042,1043,1044,1047,1048,1049,1053,1054,1058,1073,1074,1089,1090,1091,1092,1096,1106,1107,1113,1114,1131,1155,1154,1169',
    'index' => 
    array (
      'wxAdId' => 
      array (
        'cpId' => '',
        'ysId' => '',
      ),
      'tanchuang' => 
      array (
        'radio' => '1',
        'type' => '1',
        'image' => 'https://shop.io.mi-img.com/app/shop/img?id=shop_b950bb7d56f0c5a8812dceffd87fc8b5.png',
        'url' => 'wx72c54b0315d97e54',
      ),
      'share' => 
      array (
        'title' => '推荐你一款都在用的追剧神器',
        'image' => 'https://ae01.alicdn.com/kf/Uae019bd86910455d809719de222ad0c0W.jpg',
      ),
      'notice' => '系统正在升级',
      'more' => '1',
      'sy_type' => 
      array (
        0 => 
        array (
          'type_id' => '2',
          'type_name' => '同步剧场',
        ),
        1 => 
        array (
          'type_id' => '1',
          'type_name' => '最新电影',
        ),
        2 => 
        array (
          'type_id' => '4',
          'type_name' => '动画动漫',
        ),
        3 => 
        array (
          'type_id' => '3',
          'type_name' => '热门综艺',
        ),
      ),
    ),
    'detail' => 
    array (
      'play' => 
      array (
        'radio' => '0',
        'APPID' => '',
      ),
      'douban' => '1',
      'dbUpdate' => '1',
      'dbStills' => '1',
      'gg' => 
      array (
        'radio' => '0',
        'type' => '2',
        'image' => 'https://shop.io.mi-img.com/app/shop/img?id=shop_26e4998b55c7750d750cc5bf159818a8.png',
        'url' => 'https://shop.io.mi-img.com/app/shop/img?id=shop_26e4998b55c7750d750cc5bf159818a8.png',
      ),
      'wxAdId' => 
      array (
        'cpId' => '',
        'ysId' => '',
        'jlspId' => '',
      ),
      'adMsg' => 
      array (
        'start' => '努力加载中,加个广告后开始播放!',
        'close' => '广告还没看完哦，有点耐心！',
      ),
    ),
    'feilei' => 
    array (
      'wxAdId' => 
      array (
        'ysId' => '',
        'cpId' => '',
      ),
      'type_class' => '[{"type_name":"连续剧","type_id":"2","type_extend":{"class":["全部","言情","喜剧","悬疑","都市","偶像","古装","军事","警匪","历史","励志","神话","谍战","青春","家庭","动作","情景","武侠","科幻","其他"],"area":["全部","大陆","美国","香港","台湾","韩国","泰国","日本","英国","新加坡"],"lang":"全部,国语,英语,粤语,闽南语,韩语,日语,其它","year":["全部","2020","2019","2018","2017","2016","2015","2014","2013","2012","2011","2010","2009","2008","2006","2005","2004"]}},{"type_name":"电影","type_id":"1","type_extend":{"class":["全部","喜剧","爱情","动作","恐怖","科幻","剧情","犯罪","奇幻","战争","悬疑","动画","文艺","伦理","纪录","传记","歌舞","古装","历史","惊悚","其他"],"area":["全部","大陆","美国","香港","韩国","日本","法国","英国","德国","台湾","泰国","印度","其他"],"year":["全部","2020","2019","2018","2017","2016","2015","2014","2013","2012","2011","2010"]}},{"type_name":"综艺","type_id":"3","type_extend":{"class":["全部","选秀","情感","访谈","播报","旅游","音乐","美食","纪实","曲艺","生活","游戏互动","财经","求职","其他"],"area":["全部","内地","港台","日韩","欧美","其他"],"year":["全部","2020","2019","2018","2017","2016","2015","2014","2013","2012","2011","2010"]}},{"type_name":"动漫","type_id":"4","type_extend":{"class":["全部","热血","科幻","美少女","魔幻","经典","励志","少儿","冒险","搞笑","推理","恋爱","治愈","幻想","校园","动物","机战","亲子","儿歌","运动","悬疑","怪物","战争","益智","青春","童话","竞技","动作","社会","友情","真人版","电影版","OVA版","TV版","新番动画","完结动画"],"area":["全部","日本","美国","大陆"],"lang":"全部,国语,英语,粤语,闽南语,韩语,日语,其它","year":["全部","2020","2019","2018","2017","2016","2015","2014","2013","2012","2011","2010","2009","2008","2007","2006","2005","2004"]}}]',
    ),
    'topic' => 
    array (
      'wxAdId' => 
      array (
        'ysId' => '',
        'cpId' => '',
      ),
      'tags' => '',
    ),
    'play' => 
    array (
      'isPoints' => '0',
      'enforce' => '0',
      'second' => '10',
      'num' => '2',
      'interval' => 1800.0,
      'adMsg' => 
      array (
        'start' => '看视频提个速，记得播放完成哦!',
        'close' => '广告完成后才可完成加速哦!',
      ),
      'gg' => 
      array (
        'radio' => '1',
        'type' => '0',
        'image' => 'https://shop.io.mi-img.com/app/shop/img?id=shop_26e4998b55c7750d750cc5bf159818a8.png',
        'url' => 'https://mp.weixin.qq.com/s/3xGOj-gKDtgE20ZIEdPMUg',
      ),
      'wxAdId' => 
      array (
        'jlspId' => 'adunit-f3e6f5cbd701db38',
        'cpId' => '',
        'spqtId' => '',
        'ysId' => '',
        'ysgzId' => '',
      ),
      'vodPlayer' => 
      array (
        'id' => 
        array (
          0 => 'qq',
          1 => 'qiyi',
          2 => 'mgtv',
          3 => 'dbm3u8',
          4 => 'tkm3u8',
          5 => 'bjm3u8',
          6 => 'zuidam3u8',
          7 => 'yugao',
        ),
        'title' => 
        array (
          0 => '极速一',
          1 => '极速二',
          2 => '极速三',
          3 => '线路一',
          4 => '线路二',
          5 => '线路三',
          6 => '线路四',
          7 => '预告',
        ),
      ),
      'danmuList' => 
      array (
        0 => 
        array (
          'text' => '请勿相信视频内广告',
          'color' => '#ff0080',
          'time' => 1,
        ),
        1 => 
        array (
          'text' => '本软件永久免费,为避免小程序被封,请关注下方备用小程序!',
          'color' => '#0080ff',
          'time' => 10,
        ),
      ),
    ),
    'wode' => 
    array (
      'gg' => 
      array (
        'radio' => '0',
        'type' => '2',
        'image' => 'http://qiniu.vodzz.com/%E5%B0%8F%E5%B0%8F%E8%A7%A3%E6%9E%90%E5%B9%BF%E5%91%8A.gif',
        'url' => 'http://qiniu.vodzz.com/%E5%B0%8F%E5%B0%8F%E8%A7%A3%E6%9E%90%E5%B9%BF%E5%91%8A.gif',
      ),
      'statement' => '',
      'wxAdId' => 
      array (
        'ysId' => '',
      ),
      'more' => 
      array (
        'radio' => '0',
      ),
    ),
    'other' => 
    array (
      'wxAdId' => 
      array (
        'bannerId' => '',
        'cpId' => '',
        'ysId' => '',
      ),
    ),
    'hours' => NULL,
  ),
  
);