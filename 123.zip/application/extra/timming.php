<?php
return array (
  'aa' => 
  array (
    'id' => 'aa',
    'status' => '0',
    'name' => 'aa',
    'des' => '采集今日数据',
    'file' => 'collect',
    'param' => 'ac=cjday&xt=1&ct=&rday=24&cjflag=tv6_com&cjurl=http://cj2.tv6.com/mox/inc/youku.php',
    'weeks' => '1,2,3,4,5,6,0',
    'hours' => '00,01,02,03,04,05,06,07,08,09,10,11,12,13,14,15,16,17,18,19,20,21,22,23',
  ),
  'bb' => 
  array (
    'status' => '0',
    'name' => 'bb',
    'des' => '生成首页',
    'file' => 'make',
    'param' => 'ac=index',
    'weeks' => '1,2,3,4,5,6,0',
    'hours' => '00,01,02,03,04,05,06,07,08,09,10,11,12,13,14,15,16,17,18,19,20,21,22,23',
    'id' => 'bb',
    'runtime' => 1535348998,
  ),
  '明日' => 
  array (
    'id' => '明日',
    'status' => '0',
    'name' => '明日',
    'des' => '',
    'file' => 'collect',
    'param' => 'ac=cj&cjflag=8347add00f8f99e878fd53d94e9b2e8d&cjurl=http%3A%2F%2Fzy.zcocc.com%2Fapi.php%2Fprovide%2Fvod%2Fat%2Fxml%2F&h=24&t=&ids=&wd=&type=1&mid=1&opt=0&filter=1&filter_from=qiyi%2Cqq&param=',
    'weeks' => '1,2,3,4,5,6,0',
    'hours' => '00,01,02,03,04,05,06,07,08,09,10,11,12,13,14,15,16,17,18,19,20,21,22,23',
  ),
  'baidu' => 
  array (
    'status' => '1',
    'name' => 'baidu',
    'des' => '百度云',
    'file' => 'collect',
    'param' => 'ac=cj&cjflag=ed73ad1619857068fd2f38202eeb5818&cjurl=https%3A%2F%2Fm3u8.apibdzy.com%2Fapi.php%2Fprovide%2Fvod%2F%3Fac%3Dlist&h=24&t=&ids=&wd=&type=2&mid=1&opt=0&filter=0&filter_from=&param=',
    'weeks' => '1,2,3,4,5,6,0',
    'hours' => '00,01,02,03,04,05,06,07,08,09,10,11,12,13,14,15,16,17,18,19,20,21,22,23',
    'runtime' => 1603756801,
  ),
  'tiankong' => 
  array (
    'status' => '1',
    'name' => 'tiankong',
    'des' => '天空',
    'file' => 'collect',
    'param' => 'ac=cj&cjflag=39877644bdd349e231fabd93b3d34898&cjurl=https%3A%2F%2Fm3u8.tiankongapi.com%2Fapi.php%2Fprovide%2Fvod%2Fat%2Fxml%2F&h=24&t=&ids=&wd=&type=1&mid=1&opt=0&filter=1&filter_from=tkm3u8&param=',
    'weeks' => '1,2,3,4,5,6,0',
    'hours' => '00,01,02,03,04,05,06,07,08,09,10,11,12,13,14,15,16,17,18,19,20,21,22,23',
    'runtime' => 1603760402,
  ),
  'bajie' => 
  array (
    'status' => '1',
    'name' => 'bajie',
    'des' => '八戒',
    'file' => 'collect',
    'param' => 'ac=cj&cjflag=70662d022b1572d859aa947a7f0ebffa&cjurl=http%3A%2F%2Fcj.bajiecaiji.com%2Finc%2Fbjm3u8.php&h=24&t=&ids=&wd=&type=1&mid=1&opt=0&filter=0&filter_from=&param=',
    'weeks' => '1,2,3,4,5,6,0',
    'hours' => '00,01,02,03,04,05,06,07,08,09,10,11,12,13,14,15,16,17,18,19,20,21,22,23',
    'runtime' => 1603760402,
  ),
);