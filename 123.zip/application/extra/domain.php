<?php
return array (
  '' => 
  array (
    'site_url' => '',
    'site_name' => '',
    'site_keywords' => '',
    'site_description' => '',
    'template_dir' => 'no',
    'html_dir' => '',
    'ads_dir' => '',
  ),
);